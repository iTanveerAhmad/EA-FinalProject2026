package miu.cs544.releasesystem.release.dto;

import lombok.Data;

@Data
public class ReleaseRequest {
    private String name;
    private String description;
}
