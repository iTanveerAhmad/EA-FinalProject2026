package miu.cs544.releasesystem.release.event;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaskCompletedEvent {
    private String taskId;
    private String developerId;
    private String releaseId;
}
