package miu.cs544.releasesystem.release.domain;

public enum ReleaseStatus {
    IN_PROGRESS,
    COMPLETED
}
