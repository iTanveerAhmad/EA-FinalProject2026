package miu.cs544.releasesystem.release.dto;

import lombok.Data;

@Data
public class OllamaResponse {
    private String response;
    private boolean done;
}
