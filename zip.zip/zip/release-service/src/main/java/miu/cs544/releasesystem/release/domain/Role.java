package miu.cs544.releasesystem.release.domain;

public enum Role {
    ADMIN,
    DEVELOPER
}
